
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  `updated_by_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `created_at`, `updated_at`, `published_at`, `created_by_id`, `updated_by_id`, `name`, `color`) VALUES
(1, '2024-08-07 15:43:13.974000', '2024-08-21 15:32:04.052000', '2024-08-07 15:43:37.466000', 1, 1, 'เนื้อ', NULL),
(2, '2024-08-07 15:44:16.984000', '2024-08-21 15:32:28.577000', '2024-08-07 15:44:48.844000', 1, 1, 'ไก่', NULL),
(3, '2024-08-07 15:48:20.583000', '2024-08-21 15:32:47.726000', '2024-08-07 15:48:21.813000', 1, 1, 'ปลา', NULL),
(4, '2024-08-07 15:56:13.375000', '2024-08-21 15:33:43.648000', '2024-08-07 15:56:14.282000', 1, 1, 'หมู', NULL),
(5, '2024-08-07 15:57:42.292000', '2024-08-21 15:34:06.855000', '2024-08-07 15:57:43.359000', 1, 1, 'ผลไม้', NULL),
(6, '2024-08-07 15:58:36.859000', '2024-08-21 15:34:22.998000', '2024-08-07 15:58:37.785000', 1, 1, 'ผัก', NULL),
(7, '2024-08-07 15:59:56.421000', '2024-08-21 15:34:38.730000', '2024-08-07 15:59:57.091000', 1, 1, 'สลัด', NULL),
(8, '2024-08-07 16:02:34.553000', '2024-08-21 15:34:56.511000', '2024-08-07 16:02:35.971000', 1, 1, 'เครื่องดื่ม', NULL);
