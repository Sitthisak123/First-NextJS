
-- --------------------------------------------------------

--
-- Table structure for table `files_folder_links`
--

CREATE TABLE `files_folder_links` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_id` int(10) UNSIGNED DEFAULT NULL,
  `folder_id` int(10) UNSIGNED DEFAULT NULL,
  `file_order` double UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `files_folder_links`
--

INSERT INTO `files_folder_links` (`id`, `file_id`, `folder_id`, `file_order`) VALUES
(1, 22, 2, 1),
(2, 21, 2, 2),
(3, 23, 3, 1),
(4, 24, 3, 1),
(5, 26, 3, 1),
(6, 25, 3, 2),
(7, 27, 3, 2),
(8, 28, 3, 2),
(9, 29, 3, 3),
(10, 30, 3, 4),
(11, 31, 3, 5),
(12, 32, 3, 6),
(13, 33, 5, 1),
(14, 34, 5, 1),
(15, 35, 5, 2),
(16, 36, 5, 3),
(17, 37, 5, 4),
(18, 38, 5, 4),
(19, 39, 5, 5),
(20, 40, 5, 5),
(21, 41, 5, 6),
(22, 42, 5, 7),
(23, 43, 5, 8),
(26, 44, 7, 1),
(27, 45, 7, 2),
(28, 47, 7, 3),
(29, 46, 7, 3),
(30, 49, 7, 4),
(31, 48, 7, 5),
(32, 50, 7, 6),
(33, 51, 7, 7),
(34, 52, 7, 8),
(35, 53, 7, 9),
(36, 54, 7, 10);
