
-- --------------------------------------------------------

--
-- Table structure for table `up_permissions_role_links`
--

CREATE TABLE `up_permissions_role_links` (
  `id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED DEFAULT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `permission_order` double UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `up_permissions_role_links`
--

INSERT INTO `up_permissions_role_links` (`id`, `permission_id`, `role_id`, `permission_order`) VALUES
(1, 1, 1, 1),
(2, 2, 1, 1),
(3, 4, 2, 1),
(4, 3, 2, 1),
(5, 5, 2, 1),
(6, 8, 2, 1),
(7, 6, 2, 1),
(8, 9, 2, 2),
(9, 7, 2, 2),
(10, 10, 2, 3),
(11, 11, 2, 4),
(12, 12, 2, 5),
(13, 13, 2, 6),
(14, 14, 2, 7);
