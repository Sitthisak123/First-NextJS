
-- --------------------------------------------------------

--
-- Table structure for table `upload_folders`
--

CREATE TABLE `upload_folders` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path_id` int(11) DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  `updated_by_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `upload_folders`
--

INSERT INTO `upload_folders` (`id`, `name`, `path_id`, `path`, `created_at`, `updated_at`, `created_by_id`, `updated_by_id`) VALUES
(1, 'Foods', 1, '/1', '2024-08-28 14:22:04.735000', '2024-08-28 14:22:04.735000', 1, 1),
(2, 'chicken', 2, '/1/2', '2024-08-28 14:23:16.492000', '2024-08-28 14:23:16.492000', 1, 1),
(3, 'fish', 3, '/1/3', '2024-08-28 14:24:14.596000', '2024-08-28 14:24:14.596000', 1, 1),
(4, 'salad', 4, '/1/4', '2024-08-28 14:25:02.901000', '2024-08-28 14:25:02.901000', 1, 1),
(5, 'fruit', 5, '/1/5', '2024-08-28 14:25:48.339000', '2024-08-28 14:25:48.339000', 1, 1),
(7, 'Baverage', 6, '/1/6', '2024-08-28 14:38:12.138000', '2024-08-28 14:38:12.138000', 1, 1);
