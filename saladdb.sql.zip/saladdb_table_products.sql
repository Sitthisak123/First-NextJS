
-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `mrp` decimal(10,2) DEFAULT NULL,
  `selling_price` decimal(10,2) DEFAULT NULL,
  `item_quqntity_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  `updated_by_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `mrp`, `selling_price`, `item_quqntity_type`, `slug`, `created_at`, `updated_at`, `published_at`, `created_by_id`, `updated_by_id`) VALUES
(1, 'ไก่+ผักกาด', NULL, '200.00', '150.00', '300 กรัม', 'product', '2024-08-28 14:31:13.324000', '2024-08-28 14:31:20.059000', '2024-08-28 14:31:20.054000', 1, 1),
(2, 'ไก่ต้ม', NULL, '250.00', '200.00', '500กรัม', 'product-1', '2024-08-28 14:33:46.487000', '2024-08-28 14:33:47.608000', '2024-08-28 14:33:47.604000', 1, 1),
(3, 'ปลาทอดกระเทียม', NULL, '100.00', '75.00', '100 กรัม', 'product-2', '2024-08-28 14:34:51.998000', '2024-08-28 14:34:52.722000', '2024-08-28 14:34:52.719000', 1, 1),
(4, 'ซาชิมิ', NULL, '200.00', '150.00', '100 กรัม', 'product-3', '2024-08-28 14:36:10.840000', '2024-08-28 14:36:12.053000', '2024-08-28 14:36:12.050000', 1, 1),
(5, 'ปลาย้างเกลือ', NULL, '150.00', '125.00', '100 กรัม', 'product-4', '2024-08-28 14:37:21.001000', '2024-08-28 14:37:21.998000', '2024-08-28 14:37:21.995000', 1, 1),
(6, 'ส้ม', NULL, '250.00', '225.00', '1 กิโลกรัม', 'product-5', '2024-08-28 14:39:32.721000', '2024-08-28 14:39:34.187000', '2024-08-28 14:39:34.183000', 1, 1),
(7, 'แตงโม', NULL, '40.00', '35.00', '100 กรัม', 'product-6', '2024-08-28 14:40:14.840000', '2024-08-28 14:40:15.617000', '2024-08-28 14:40:15.614000', 1, 1);
