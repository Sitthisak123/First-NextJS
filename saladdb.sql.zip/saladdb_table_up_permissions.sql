
-- --------------------------------------------------------

--
-- Table structure for table `up_permissions`
--

CREATE TABLE `up_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  `updated_by_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `up_permissions`
--

INSERT INTO `up_permissions` (`id`, `action`, `created_at`, `updated_at`, `created_by_id`, `updated_by_id`) VALUES
(1, 'plugin::users-permissions.user.me', '2024-08-07 15:10:40.925000', '2024-08-07 15:10:40.925000', NULL, NULL),
(2, 'plugin::users-permissions.auth.changePassword', '2024-08-07 15:10:40.925000', '2024-08-07 15:10:40.925000', NULL, NULL),
(3, 'plugin::users-permissions.auth.callback', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(4, 'plugin::users-permissions.auth.connect', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(5, 'plugin::users-permissions.auth.emailConfirmation', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(6, 'plugin::users-permissions.auth.forgotPassword', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(7, 'plugin::users-permissions.auth.sendEmailConfirmation', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(8, 'plugin::users-permissions.auth.resetPassword', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(9, 'plugin::users-permissions.auth.register', '2024-08-07 15:10:40.941000', '2024-08-07 15:10:40.941000', NULL, NULL),
(10, 'api::category.category.find', '2024-08-07 15:51:26.660000', '2024-08-07 15:51:26.660000', NULL, NULL),
(11, 'api::category.category.findOne', '2024-08-07 15:51:26.660000', '2024-08-07 15:51:26.660000', NULL, NULL),
(12, 'api::slider.slider.find', '2024-08-21 15:48:19.954000', '2024-08-21 15:48:19.954000', NULL, NULL),
(13, 'api::product.product.find', '2024-08-28 14:40:43.748000', '2024-08-28 14:40:43.748000', NULL, NULL),
(14, 'api::product.product.findOne', '2024-08-28 14:40:43.748000', '2024-08-28 14:40:43.748000', NULL, NULL);
