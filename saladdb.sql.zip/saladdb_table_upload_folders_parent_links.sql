
-- --------------------------------------------------------

--
-- Table structure for table `upload_folders_parent_links`
--

CREATE TABLE `upload_folders_parent_links` (
  `id` int(10) UNSIGNED NOT NULL,
  `folder_id` int(10) UNSIGNED DEFAULT NULL,
  `inv_folder_id` int(10) UNSIGNED DEFAULT NULL,
  `folder_order` double UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `upload_folders_parent_links`
--

INSERT INTO `upload_folders_parent_links` (`id`, `folder_id`, `inv_folder_id`, `folder_order`) VALUES
(1, 2, 1, 1),
(2, 3, 1, 2),
(3, 4, 1, 3),
(4, 5, 1, 4),
(5, 7, 1, 5);
