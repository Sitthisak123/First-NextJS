
-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  `updated_by_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `name`, `type`, `created_at`, `updated_at`, `published_at`, `created_by_id`, `updated_by_id`) VALUES
(1, 'slide1', 'home', '2024-08-21 15:45:48.541000', '2024-08-21 16:18:20.054000', '2024-08-21 16:18:20.048000', 1, 1),
(2, 'slide2', 'home', '2024-08-21 15:46:33.752000', '2024-08-21 16:18:23.138000', '2024-08-21 16:18:23.133000', 1, 1),
(3, 'slide3', 'home', '2024-08-21 15:46:58.901000', '2024-08-21 16:18:26.378000', '2024-08-21 16:18:26.375000', 1, 1);
