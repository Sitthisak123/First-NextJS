
-- --------------------------------------------------------

--
-- Table structure for table `files_related_morphs`
--

CREATE TABLE `files_related_morphs` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_id` int(10) UNSIGNED DEFAULT NULL,
  `related_id` int(10) UNSIGNED DEFAULT NULL,
  `related_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` double UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `files_related_morphs`
--

INSERT INTO `files_related_morphs` (`id`, `file_id`, `related_id`, `related_type`, `field`, `order`) VALUES
(12, 10, 1, 'api::category.category', 'icon', 1),
(13, 11, 2, 'api::category.category', 'icon', 1),
(14, 12, 3, 'api::category.category', 'icon', 1),
(15, 13, 4, 'api::category.category', 'icon', 1),
(16, 14, 5, 'api::category.category', 'icon', 1),
(17, 15, 6, 'api::category.category', 'icon', 1),
(18, 16, 7, 'api::category.category', 'icon', 1),
(19, 17, 8, 'api::category.category', 'icon', 1),
(20, 18, 1, 'api::slider.slider', 'image', 1),
(21, 19, 2, 'api::slider.slider', 'image', 1),
(22, 20, 3, 'api::slider.slider', 'image', 1),
(24, 22, 1, 'api::product.product', 'images', 1),
(25, 21, 2, 'api::product.product', 'images', 1),
(26, 26, 3, 'api::product.product', 'images', 1),
(27, 29, 4, 'api::product.product', 'images', 1),
(28, 24, 5, 'api::product.product', 'images', 1),
(29, 50, 6, 'api::product.product', 'images', 1),
(30, 47, 7, 'api::product.product', 'images', 1);
